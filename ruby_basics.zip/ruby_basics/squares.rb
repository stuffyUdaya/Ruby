x=[1,5,10,-2]
for i in 0..x.length
  x[i] = x[i]*x[i]

puts x.to_s
end  
