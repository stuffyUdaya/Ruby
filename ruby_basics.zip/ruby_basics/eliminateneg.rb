x = [1,5,10,-2]
for i in 0..x.length
  if(x[i]<0)
    x[i] =0
  end
  puts x.to_s
end
