i =0
num =5

while i<num do
  puts "inside the loop i = #{i}"
  i=i+1
  # break if i ==3
end
