puts "Hello"
puts "welcome"
puts "Ninja"

print "Hello"
print "Coding"
print "Ninja"

# comment
# executing ruby files: ruby {{filename}} in your terminal

BEGIN{
  puts "this is in the begin block"
}


END{
  puts "this is in the end last block"
}
