x=[-3,-5,7]
max = x[0]


for i in 0..x.length
  if x[i]>max
      max= x[i]
  end
  puts "max is #{max}"
end
