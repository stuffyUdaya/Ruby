x =60; y= 45; z = x+y;
puts "sum is #{z} "

puts "sum is ", +z

puts "sum is %d" %z

name = "udaya"

puts "This is %s"%name

puts "\t\tThis\n is \t%s"%name


a ="this"
b = " is"

puts a+b
