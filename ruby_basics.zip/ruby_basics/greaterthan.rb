x = [1,3,5,7]
y=3
counter =0

for i in 0..x.length
  if x[i]>3
    counter+=1
  end
  puts counter
end
