x = [2,10,3]
sum =0
for i in 0..x.length
 # (0..x.length).each do |i|

  sum =sum+x[i]
puts sum


avg= sum/x.length
puts "avg is #{avg}"
end
