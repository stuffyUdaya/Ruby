sum =0
for i in 0..255
  sum = sum+i
  puts "new number #{i} Sum #{sum} "
end
