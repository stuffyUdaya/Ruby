y=[]
for i in 1..255
  if i%2!=0
    y.push(i)
  end

puts y.to_s
end
