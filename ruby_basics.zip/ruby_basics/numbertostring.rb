x=[-1,-3,2]
for i in 0..x.length
  if(x[i]<0)
    x[i] = "Dojo"
  end

  puts x.to_s
end
