for i in 1..255
  puts "The nmber is #{i}"
end
