for i in 1..255
  if i%2 !=0
    puts "#{i} is an odd number"
  end
end  
