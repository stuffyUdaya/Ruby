x ="udaya tummala"
puts x. length
puts x. size
puts x.capitalize

puts x. class

puts x.upcase

puts x.downcase

puts x[2]

puts x[0]

puts"Hello" if x.include?("Udaya")
puts"Hello" if x.include?("udaya")

puts x.include?("udaya")



x = "dan,elon,jack,tom"
puts x.split(",").to_s
puts x.split(",")

y = ""

puts "Y is empty" if y.empty?
