class UsersController < ApplicationController
  def index
    render json:User.all
  end
  def new
  end
  def show
    id = params[:id]
    puts id
    render json:User.find(id)
    end
  def edit
    id = params[:id]
    @user = User.find(id)
    puts @user
  end
  def create
    User.create(fname:params[:fname], lname:params[:lname])
    redirect_to"/users"
  end
  def update
    user = User.find(params[:id])
    user.fname = params[:fname]
    user.lname = params[:lname]
    user.save
    redirect_to"/users"
  end
  def total
    @count = User.all.count
    puts @count
    render text:"Total number of users were #{@count}"
  end
end
