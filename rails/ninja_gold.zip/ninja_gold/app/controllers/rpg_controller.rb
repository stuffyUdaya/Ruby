class RpgController < ApplicationController
  def index
    session[:gold] ||= 0
  end

  def farm
    session[:gold]= session[:gold]+rand(10..20)
    puts session[:gold]
    redirect_to'/index'

  end

  def cave
    session[:gold]= session[:gold]+rand(5..10)
    puts session[:gold]
    redirect_to'/index'

  end

  def house
    session[:gold]= session[:gold]+rand(2..5)
    puts session[:gold]
    redirect_to'/index'

  end

  def casino
    session[:gold]= session[:gold]+rand(-50..50)
    puts session[:gold]
    redirect_to'/index'

  end

  def reset
    session[:gold] =0
    redirect_to '/index'
  end


end
