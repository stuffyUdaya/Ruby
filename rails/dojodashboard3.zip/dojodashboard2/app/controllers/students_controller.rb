class StudentsController < ApplicationController
  def index
    id = params[:dojo_id]
     @students = Student.joins(:dojo).where("dojo_id=#{id}")
     @dojo = Dojo.find(id)
  end
  def new
    id = params[:dojo_id]
    @dojo = Dojo.find(id)

  end
  def create
    student =  Student.create(first_name: params[:first_name], last_name: params[:last_name], email: params[:email], dojo_id: params[:dojo])
    redirect_to'/dojos'
  end

  def show
    id = params[:id]
    puts id
    dojoid = params[:dojo_id]
    @students = Student.joins(:dojo).where("dojo_id=#{dojoid}").where("students.id!=#{id}")
    @student = Student.find(id)

  end

  def edit
    dojoid = params[:dojo_id]
    id = params[:id]
    @dojo = Dojo.find(dojoid)
    @student = Student.find(id)
  end

  def update
    id = params[:id]
    dojoid = params[:dojo_id]
    student = Student.find(id)
    student.update(first_name: params[:first_name])
    student.update(last_name: params[:last_name])
    student.update(email: params[:email])

    redirect_to'/dojos'


  end
  def destroy
    id = params[:id]
    dojoid = params[:dojo_id]
    Student.destroy(id)
    redirect_to'/dojos'
  end

end
