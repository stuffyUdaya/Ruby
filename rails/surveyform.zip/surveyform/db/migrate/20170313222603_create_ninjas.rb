class CreateNinjas < ActiveRecord::Migration
  def change
    create_table :ninjas do |t|
      t.string :name
      t.string :dojoloc
      t.string :favlang
      t.text :comment

      t.timestamps null: false
    end
  end
end
