class Ninja < ActiveRecord::Base
end
