class NinjaController < ApplicationController
  def index
    session[:views] ||= 0
puts    Ninja.all

  end
  def new
    session[:views] = session[:views] + 1
   session[:result] =  Ninja.create(name:params[:name],dojoloc: params[:dojoloc], favlang:params[:favlang], comment:params[:comment] )
   flash[:success] = "Thanks for submitting this form! You have submitted this form #{ session[:views] } time(s) now."
    redirect_to '/result'
  end
  def result
     @result = session[:result]
  end
end
