require 'test_helper'

class NinjaControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
