require 'test_helper'

class DisplaysControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
